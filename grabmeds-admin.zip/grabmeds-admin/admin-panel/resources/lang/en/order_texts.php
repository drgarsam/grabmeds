<?php

return [
    'searching_for_delivery_man'=>'Searching for Deliveryman',
    'accepted_by_delivery_man'=>'Accepted by Deliveryman',
    'preparing_in_restaurants'=>'Processing',
    'picked_up'=>'Picked Up',
    'dashboard_order_statistics'=>'Dashboard Order Statistics',
];
