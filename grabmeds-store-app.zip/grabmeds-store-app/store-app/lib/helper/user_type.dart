enum UserType {
  customer,
  user,
  delivery_man,
  vendor
}
