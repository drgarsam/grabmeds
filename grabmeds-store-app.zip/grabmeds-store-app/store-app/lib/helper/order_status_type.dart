enum OrderStatusType{
  pending,
  take_away,
  confirmed,
  processing,
  accepted,
  handover,
  picked_up,
}