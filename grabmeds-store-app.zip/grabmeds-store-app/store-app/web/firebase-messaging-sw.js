importScripts("https://www.gstatic.com/firebasejs/7.20.0/firebase-app.js");
importScripts("https://www.gstatic.com/firebasejs/7.20.0/firebase-messaging.js");

firebase.initializeApp({
    apiKey: "AIzaSyCKHF5gYLrNP7qYKK5IPe0KfXYv9J_QS9g",
    authDomain: "grabmedicine-project.firebaseapp.com",
    projectId: "grabmedicine-project",
    storageBucket: "grabmedicine-project.appspot.com",
    messagingSenderId: "16734250330",
    appId: "1:16734250330:web:0fb3b8c6b59fac36f3bf63",
    databaseURL: "...",
});

const messaging = firebase.messaging();

// Optional:
messaging.onBackgroundMessage((message) => {
  console.log("onBackgroundMessage", message);
});