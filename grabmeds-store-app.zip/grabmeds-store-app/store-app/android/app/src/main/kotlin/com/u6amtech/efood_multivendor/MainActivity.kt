package com.project.grabmedicine_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
