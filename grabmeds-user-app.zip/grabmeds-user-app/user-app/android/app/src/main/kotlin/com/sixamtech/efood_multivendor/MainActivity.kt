package com.project.grabmedicine

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
