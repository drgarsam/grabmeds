enum RestaurantType {
  ALL_RESTAURANT,
}